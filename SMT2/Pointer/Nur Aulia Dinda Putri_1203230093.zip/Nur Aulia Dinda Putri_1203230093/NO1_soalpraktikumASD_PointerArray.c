#include <stdio.h> 

//fungsi untuk mengubah nilai menjadi integer
int nama_kartu(char remi)
{
  if (remi == 'J')
    return 11;
  else if (remi == 'Q')
    return 12;
  else if (remi == 'K')
    return 13;
  else if (remi == '1')
    return 10;
  else
    return remi - '0';
}

//fungsi untuk mencetak isi dari array
void printCards(char *remi, int panjang)
{
  for (int i = 0; i < panjang; i++)
  {
    printf("%c ", remi[i]);
  }
  printf("\n");
}

//untuk mengurutkan kartu dalam urutan berdasarkan nilainya 
 int swapping(int b, char *remi)
{
  int swaps = 0;
  for (int i = 0; i < b - 1; i++)
  {
    int min_idx = i;
    for (int j = i + 1; j < b; j++)
    {
      if (nama_kartu(remi[j]) < nama_kartu(remi[min_idx]))
      {
        min_idx = j;
      }
    }
    if (min_idx != i)
    {
      char temp = remi[i];
      remi[i] = remi[min_idx];
      remi[min_idx] = temp;
      swaps++;

      printf("Pertukaran %d : ", swaps);
      printCards(remi, b);
    }
  }
  return swaps;
}

int main() {
  int b;

  // Membaca jumlah kartu
  printf("Masukkan jumlah kartu: ");
  scanf("%d", &b);

  char remi[b];

  // Membaca nilai kartu
  printf("Masukkan nilai kartu: ");
  for (int i = 0; i < b; i++) {
    scanf(" %c", &remi[i]);
  }

  int swaps = swapping(b, remi);

  // Menampilkan hasil
  printf("Jumlah pertukaran dari kartu remi : %d\n", swaps);

  return 0;
}
