#include <stdio.h>

void koboImaginaryChess (int i, int j, int size, int *chessBoard){ 
    int arr2d[8][2] = {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}}; 
    for (int x = 0; x < 8; x++){ 
        int y = i + arr2d[x][0]; 
        int z = j + arr2d[x][1]; 
        if(y >= 0 && y < size && z >= 0 && z < size){ 
            *(chessBoard + y*size + z) = 1;
        }
    }
}

int main(){
    int i, j;
    scanf("%d %d", &i, &j); 
    int chessBoard[8][8] = {0}; 
    koboImaginaryChess(i, j, 8, (int *)chessBoard); 
    for(int x = 0; x < 8; x++){ 
        for(int a = 0; a < 8; a++){
            printf("%d", chessBoard[x][a]);
        }
        printf("\n");
    }
    return 0;
}